import{r as e,t}from"./chunk-QB3YPZ4I.DmjMPFZY.js";import"./chunk-XXDRQBXY.YR5f9nPB.js";import"./chunk-TU62E6Q5.C_2HqdYK.js";import"./mermaid.core.By56uoFp.js";import"./chunk-HFQBQIA3.CnfQKbbk.js";import"./chunk-M57EVK23.D2o62Xdz.js";import"./chunk-DQASFODM.Dtt3wJpE.js";import"./chunk-LEVMRMFU.BLW5-fXj.js";import"./chunk-AXFCVDMN.D8Vth-HR.js";import"./chunk-X4PVCEUW.CAvtWf7T.js";import"./chunk-STOXU5M4.8tKcYNsv.js";import"./chunk-R3KSYZAL.0ReLlsXp.js";import"./chunk-6MUBBAK2.BH_KuOaA.js";import"./chunk-BG4553SI.rufu1NGx.js";import"./src.BS7pU7C5.js";import{n}from"./chunk-Y2CYZVJY.DsF7k-Jl.js";var r=t({styles:n(t=>`${e(t)}
  .swimlane.cluster:not([data-color-id]) rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};